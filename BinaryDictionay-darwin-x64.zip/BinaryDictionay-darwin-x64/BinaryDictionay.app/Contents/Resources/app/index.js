/////////////////////////////////////////////////////////
//                                                     //
//                       _oo0oo_                       //
//                      o8888888o                      //
//                      88" . "88                      //
//                      (| -_- |)                      //
//                      0\  =  /0                      //
//                    ___/`---'\___                    //
//                  .' \\|     |// '.                  //
//                 / \\|||  :  |||// \                 //
//                / _||||| -:- |||||- \                //
//               |   | \\\  -  /// |   |               //
//               | \_|  ''\---/''  |_/ |               //
//               \  .-\__  '-'  ___/-. /               //
//             ___'. .'  /--.--\  `. .'___             //
//          ."" '<  `.___\_<|>_/___.' >' "".           //
//         | | :  `- \`.;`\ _ /`;.`/ - ` : | |         //
//         \  \ `_.   \_ __\ /__ _/   .-` /  /         //
//     =====`-.____`.___ \_____/___.-`___.-'=====      //
//                       `=---='                       //
//                                                     //
//                                                     //
//     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~     //
//                                                     //
//  KHÔNG BUG                            KHÔNG CRASH   //
//                                                     //
//                   A DI ĐÀ PHẬT!                     //
//                                                     //
/////////////////////////////////////////////////////////
const{app:app,BrowserWindow:BrowserWindow,ipcMain:ipcMain,dialog:dialog}=require("electron"),path=require("path"),Model=require("./src/main/electron/model"),search=require("./src/core/binarySearch"),comparator=require("./src/main/electron/constants"),writeWord=require("./src/main/electron/writeFile");let mainWindow;const createWindow=()=>{mainWindow=new BrowserWindow({width:1e3,minWidth:850,maxWidth:1e3,height:750,minHeight:700,maxHeight:750,webPreferences:{nodeIntegration:!0,contextIsolation:!1,preload:path.join(__dirname,"./src/preload"),devTools:!1}}),mainWindow.removeMenu(),mainWindow.loadFile(path.join(__dirname,"src","renderer","index.html"))};app.whenReady().then((()=>{createWindow(),app.on("activate",(()=>{0===BrowserWindow.getAllWindows().length&&createWindow()}))})),app.on("window-all-closed",(()=>{"darwin"!==process.platform&&app.quit()}));let wordsRef,forestWordEV=[],forestWordVE=[];function addWord(e,o,t,r){if(e.length){let n;for(let o=0;o<e.length;o++)if(t.word<e[o].word){n=o;break}const i=e.slice(0,n+1),d=e.slice(n,e.length);i[n]=t,r[o]=[...i,...d]}else r[o].push(t)}app.on("ready",(()=>{for(let e=0;e<26;e++)forestWordEV.push(Model.init("av",(e+10).toString(36)));for(let e=0;e<26;e++)["f","w","j","z"].includes((e+10).toString(36))?forestWordVE.push([]):forestWordVE.push(Model.init("va",(e+10).toString(36)));wordsRef=forestWordEV})),ipcMain.on("trans-type",((e,o)=>{"ev"===o&&(wordsRef=forestWordEV),"ve"===o&&(wordsRef=forestWordVE)})),ipcMain.on("search-value",((e,o)=>{const t=o.trim(),r=+t.charCodeAt(0)-97;if(t.length){const e=wordsRef[r];if(e&&e.length){const o=search(e,{word:t},comparator);mainWindow.webContents.send("search-value-result",e[o])}}})),ipcMain.on("get-list",((e,o)=>{const{character:t}=o,r=+t.charCodeAt(0)-97;o.request&&mainWindow.webContents.send("get-list-result",wordsRef[r])})),ipcMain.on("add-word",((e,o)=>{const{objEV:t,objVE:r}=o,n=+t.word.charCodeAt(0)-97,i=forestWordEV[n],d=+r.word.charCodeAt(0)-97,a=forestWordVE[d],s=search(i,{word:t.word},comparator),c=search(a,{word:r.word},comparator),h={type:"info",buttons:["Thôi khỏi, cảm ơn","Tra luôn!"],defaultId:1,title:" Thêm từ thành công!",message:"Người anh (chị) em đã thêm từ thành công",detail:"Vào tra từ đã thêm luôn chứ chờ gì nữa! :)"};let l=!1;if(-1===s)addWord(i,n,t,forestWordEV),writeWord("av",t.word.charAt(0),forestWordEV[n]),l=!0;else{const e={type:"warning",buttons:["Đồng ý","Không"],defaultId:2,title:" Từ đã tồn tại trong dữ liệu Anh - Việt!",message:"Bạn có muốn ghi đè lại từ này?",detail:"Việc ghi đè sẽ mất thông tin của từ cũ, chắc chắn chứ??"};0===dialog.showMessageBoxSync(mainWindow,e)?(i[s]=t,forestWordEV[n]=i,writeWord("av",t.word.charAt(0),forestWordEV[n]),l=!0):l=!1}if(-1===c)addWord(a,d,r,forestWordVE),writeWord("va",r.word.charAt(0),forestWordVE[d]),l=!0;else{const e={type:"warning",buttons:["Đồng ý","Không"],defaultId:2,title:" Từ đã tồn tại trong dữ liệu Việt - Anh",message:"Bạn có muốn ghi đè lại từ này?",detail:"Việc ghi đè sẽ mất thông tin của từ cũ, chắc chắn chứ??"};0===dialog.showMessageBoxSync(mainWindow,e)?(a[c]=r,forestWordVE[d]=a,writeWord("va",r.word.charAt(0),forestWordVE[d]),l=!0):l=!1}if(l){1===dialog.showMessageBoxSync(mainWindow,h)&&mainWindow.webContents.send("add-word-success")}})),ipcMain.on("error-add-word",(()=>{dialog.showMessageBox(mainWindow,{type:"error",buttons:["ok"],defaultId:1,title:" CÓ GÌ ĐÓ KHUM ỔN?",message:"Thêm từ thất bại",detail:"Có lẽ bạn đã bỏ sót trường (*) nào đó, hãy kiểm tra lại!"})}));